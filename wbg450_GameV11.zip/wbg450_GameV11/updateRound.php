<?php
	
//=================================================================================
// YOUR BUSINESS NAME
// PROJECT TITLE:		WBGPOKER GAME
// PROJECT DATE:		10/10/2017
// PROGRAMMER: 			Antonio Marrero Bonilla
// FILE NAME:			updateRound.php
// DESCRIPTION:			Increments current round in game table
// LAST UPDATE:			10/10/2017
//=================================================================================

require_once("settings.inc.php");

//=================================================================================
// GLOBALS & CONSTANTS
//=================================================================================


//=================================================================================

// INCOMING VARIABLES
//=================================================================================
//this will be the incoming player requesting a new game
$g_id = $_POST['g_id'];
if(!isset($g_id)){
	$g_id = $_GET['g_id'];
} // end if
	
$theRound= $_POST['theRound'];
if(!isset($theRound)){
	$theRound = $_GET['theRound'];
} // end if
	
//=================================================================================
// MAIN
//=================================================================================

$query = "UPDATE `game` SET `g_currentRound` = '$theRound' WHERE `g_id` = $g_id";
$result = @mysqli_query($link,$query);
if(mysqli_error($link)) handleError("query 1");

print "myStatus=OK&dummy=dummy";

?>
	